#ifndef BANKACCOUNT_HPP
#define BANKACCOUNT_HPP

#include <string>

class BankAccount {
    public:
        BankAccount(std::string first, std::string last, double initBalance);
        BankAccount(std::string first, std::string last);

        double GetBalance();
        std::string GetFirstName();
        std::string GetLastName();

        void SetFirstName(std::string name);
        void SetLastName(std::string name);

        bool Withdrawal(double amount);
        bool Deposit(double amount);

        virtual std::string ToString() = 0;

        virtual std::string Serialize() = 0;

        virtual ~BankAccount() {};

    private:
        std::string m_FirstName;
        std::string m_LastName;
        double m_Balance;
};

#endif