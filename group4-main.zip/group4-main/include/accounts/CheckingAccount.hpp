#ifndef CHECKINGACCOUNT_HPP
#define CHECKINGACCOUNT_HPP

#include "BankAccount.hpp"
#include <list>
#include <string>
#include <vector>
#include <boost/algorithm/string/join.hpp>

class CheckingAccount : public BankAccount {
    public:
        CheckingAccount(std::string first, std::string last, double initBalance, std::list<double> initCheckLog);
        CheckingAccount(std::string first, std::string last, double initBalance);
        CheckingAccount(std::string first, std::string last);

        bool WriteCheck(BankAccount &a, double amount);

        std::string ToString();

        std::string Serialize() override;

        std::list<double> GetCheckLog();

        ~CheckingAccount() {}

    private:
        std::list<double> m_CheckLog;
};

#endif