#ifndef ACCOUNTMANAGER_HPP
#define ACCOUNTMANAGER_HPP

#include <map>
#include <list>
#include <string>
#include <fstream>
#include <iterator>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string.hpp>
#include "BankAccount.hpp"
#include "Utils.hpp" // For MakeAccount()

class AccountManager {
private:
    int accountCount; //Tracks the total number of accounts
    std::map<std::string, BankAccount*> accounts;  // Maps usernames to BankAccount objects
    bool rosterAutoSave;

public:
    // Default constructor
    AccountManager();

    // Additional constructor to allow for 
    AccountManager(bool autoSave);

    // Adds a new account if username is unused
    bool AddAccount(std::string& username);

    // Deletes an account by username
    bool DeleteAccount(std::string& username);

    // Displays account information
    void DisplayAccount(std::string& username);

    // Withdraws from a specific account
    bool MakeWithdrawal(std::string& username, double amount);

    // Deposits into a specific account
    bool MakeDeposit(std::string& username, double amount);

    // Adds interest to all savings accounts
    void AddInterest();

    // Writes a check from one user to another
    bool WriteCheck(std::string& checkWriter,
                    std::string& checkReceiver,
                    double amount);

    // Getter for account count
    int GetAccountCount();

    // Saves data for all accounts to a file for data persistence
    void Serialize(std::string filename = "Bank_Account_Roster.csv");

    void Deserialize(std::string filename = "Bank_Account_Roster.csv");

    // Destructor, frees dynamic memory
    ~AccountManager();
};

#endif