#ifndef SAVINGSACCOUNT_HPP
#define SAVINGSACCOUNT_HPP

#include "BankAccount.hpp"
#include <string>
#include <array>
#include <boost/algorithm/string/join.hpp>

class SavingsAccount : public BankAccount {
    public:
        SavingsAccount(std::string first, std::string last, double initBalance, double interest);
        SavingsAccount(std::string first, std::string last, double interest);

        double GetInterestRate();

        void SetInterestRate(double interest);

        void AccrueInterest();

        std::string ToString();

        std::string Serialize() override;

        ~SavingsAccount() {}

    private:
        double m_InterestRate;
};

#endif