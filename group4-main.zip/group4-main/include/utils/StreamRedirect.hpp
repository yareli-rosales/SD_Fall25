#ifndef STREAMREDIRECT_HPP
#define STREAMREDIRECT_HPP

#include <iostream>
#include <sstream>
#include <string>
#include <streambuf>

#include "Utils.hpp"

namespace IOUtils{
	class StreamRedirect : public std::stringstream{
		public:
			StreamRedirect(std::ios& stream);
			~StreamRedirect();

			bool Divert();
			void Revert();

		private:

			std::ios& m_ModStream;
			std::streambuf* m_OldBufferPtr;
	};
}

#endif