#include "BankAccount.hpp"
#include "CheckingAccount.hpp"
#include "SavingsAccount.hpp"

#include <string>
#include <limits>

namespace AccountUtils{
    BankAccount* MakeAccount();
}

namespace IOUtils{
    // Prints msg along with a "[STATUS]" tag to the console
    void StatusMessage(std::string msg);

    // Prints msg along with a "[ERROR]" tag to the console
    void ErrorMessage(std::string msg);

    void ClearScreen();

    namespace MainMenu{
        size_t GetOption();
    }

    std::string GetString(std::string msg);

    double GetDouble(std::string msg);
}
