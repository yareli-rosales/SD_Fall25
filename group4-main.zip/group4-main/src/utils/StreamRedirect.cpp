#include "StreamRedirect.hpp"

namespace IOUtils{
	StreamRedirect::StreamRedirect(std::ios& stream) : m_ModStream(stream), m_OldBufferPtr(nullptr) {
	}

    StreamRedirect::~StreamRedirect() {
		// If OldBuffer isnt nullptr then the stream has already been diverted and hast been reverted
		if(m_OldBufferPtr){
			Revert();
			IOUtils::ErrorMessage("Stream was left in a diverted state. Stream was automatically reverted on object distruction.");	// Warn the user that they forgot to Revert the stream
		}
    }

    bool StreamRedirect::Divert() {
		// If OldBuffer isnt nullptr then the stream has already been diverted
		if (m_OldBufferPtr) {
			return false;
		}
		m_OldBufferPtr = m_ModStream.rdbuf(std::stringstream::rdbuf());
		return true;
	}

	void StreamRedirect::Revert() {
		m_ModStream.rdbuf(m_OldBufferPtr);
		m_OldBufferPtr = nullptr;
	}	
}
