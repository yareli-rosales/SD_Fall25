#include "Utils.hpp"
#include <iostream>
namespace AccountUtils{
    BankAccount* MakeAccount(){
        BankAccount* acct = nullptr;

        std::string first = IOUtils::GetString("Enter the first name:");

        std::string last = IOUtils::GetString("Enter the last name:");
        
        std::string choice = IOUtils::GetString("Would you like to make a savings (1) or checking (2) account:");

        if(choice == "1"){
            double interestRate;

            try{
                interestRate = IOUtils::GetDouble("Enter the interest rate:");
            } catch (const std::invalid_argument& e) {
                IOUtils::ErrorMessage(e.what());
                return nullptr;
            }

            if(interestRate < 0 || interestRate > 1){
                IOUtils::ErrorMessage("I'm sorry, that is not a valid interest rate.");
                return nullptr;
            }
            acct = new SavingsAccount(first, last, interestRate);
        }
        else if(choice == "2"){
            acct = new CheckingAccount(first, last);
        }
        else{
            IOUtils::ErrorMessage("I'm sorry, that is not a valid choice.");
        }

        return acct;
    }
}

namespace IOUtils{
    void StatusMessage(std::string msg){
        std::cout << "[STATUS]: " << msg << std::endl;
    }

    void ErrorMessage(std::string msg){
        std::cout << "[ERROR]: " << msg << std::endl;
    }
    
    void ClearScreen(){
        // Clear the screen and move cursor to home position (1,1)
        std::cout << "\033[2J\033[1;1H";
        std::cout.flush(); // Ensure the output is immediately sent to the terminal
    }

    namespace MainMenu{
        size_t GetOption(){
            bool finished = false;
            size_t userInput;

            while(!finished) {
                std::cout << "Options" << std::endl;
                std::cout << "0) Exit" << std::endl;
                std::cout << "1) Make account" << std::endl;
                std::cout << "2) Deposit to existing account" << std::endl;
                std::cout << "3) Withdraw from existing account" << std::endl;
                std::cout << "4) Display existing account" << std::endl;
                std::cout << "5) Accrue Interest" << std::endl;
                std::cout << "6) Write a check" << std::endl;
                std::cout << "What would you like to do (Input single number):" << std::endl;
                
                if(!(std::cin >> userInput)){
                    std::cout << "Error: Invalid Choice. Input couldnt be cast to size_t." << std::endl;

                    // Handle the error, e.g., clear the error flags, ignore remaining input
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

                    std::cin.get(); // Wait for enter press
                    ClearScreen();
                }
                else if(userInput < 0 || userInput > 6){
                    std::cout << "Error: Option Not Found" << std::endl;
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore any previous newline input
                    std::cin.get(); // Wait for enter press
                    ClearScreen();
                }
                else{
                    finished = true;
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Clean up after. Make sure to erase any extra input up to newline that may have been left behind
                }
            }
            return userInput;
        }
    }

    std::string GetString(std::string msg){
        std::string userInput;
        std::cout << msg << std::endl;
        std::getline(std::cin, userInput);
        return userInput;
    }

    double GetDouble(std::string msg){
        std::cout << msg << std::endl;

        double userInput;
        if(!(std::cin >> userInput)){
            throw std::invalid_argument("User Input Could Not Be Cast To Type: Double");
        }

        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Clean up after. Make sure to erase any extra input up to newline that may have been left behind
        return userInput;
    }
}
