#include "BankAccount.hpp"
#include "CheckingAccount.hpp"
#include "SavingsAccount.hpp"
#include "AccountManager.hpp"
#include "Utils.hpp"

#include <iostream>
#include <map>
#include <string>

int main(){
    std::cout << "Welcome to the banking software!" << std::endl;

    bool finished = false;

    AccountManager manager;

    manager.Deserialize(); // Read and load accounts from default save file.

    while(!finished){
        size_t choice = IOUtils::MainMenu::GetOption();

        if(choice == 0){
            IOUtils::StatusMessage("Exiting, thank you for using the software");
            finished = true;
        }
        else if(choice == 1){
            std::string user = IOUtils::GetString("Enter the username: ");

            if(!manager.AddAccount(user)) {
                IOUtils::ErrorMessage("Sorry, that username is taken");
            }
        }  
        else if(choice == 2){
            std::string user = IOUtils::GetString("Enter the username: ");
            
            double depositAmount = 0.0;
            try{
                depositAmount = IOUtils::GetDouble("Enter amount: ");
            } catch (const std::invalid_argument& e) {
                IOUtils::ErrorMessage(e.what());
            }
            if (!manager.MakeDeposit(user, depositAmount)) {
                IOUtils::ErrorMessage("Account not found");
                continue;
            }

        }
        else if(choice == 3){
            std::string user = IOUtils::GetString("Enter the username: ");
            double withdrawalAmount = 0.0;
            try{
                withdrawalAmount = IOUtils::GetDouble("Enter amount: ");
            } catch (const std::invalid_argument& e) {
                IOUtils::ErrorMessage(e.what());
                continue;
            }
            if (!manager.MakeWithdrawal(user, withdrawalAmount)) {
                IOUtils::ErrorMessage("Withdrawal failed (no account or insufficient funds)");
            }
        }
        else if(choice == 4){
            std::string user = IOUtils::GetString("Enter the username: ");
            manager.DisplayAccount(user);
        }
        else if(choice == 5) {
            manager.AddInterest();
            IOUtils::StatusMessage("Interest added to all savings accounts");
        }
        else if(choice == 6){

            std::string writer = IOUtils::GetString("Enter username of check writer: ");
            std::string receiver = IOUtils::GetString("Enter check receiver username: ");
            double depositAmount = 0.0;
            try{
                depositAmount = IOUtils::GetDouble("Enter amount: ");
            } catch (const std::invalid_argument& e) {
                IOUtils::ErrorMessage(e.what());
                continue;
            }
            if (!manager.WriteCheck(writer, receiver, depositAmount)) {
                IOUtils::ErrorMessage("Check failed (invalid accounts or insufficient funds)");
            }
            else {
                std::cout << "Check of $" << depositAmount << " successfully written from '" << writer << "' to '" << receiver << "'." << std::endl;
            }         
        }
    }
    
    return 0;
}