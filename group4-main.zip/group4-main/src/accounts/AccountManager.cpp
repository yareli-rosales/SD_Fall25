#include "AccountManager.hpp"
#include "Utils.hpp"
#include <iostream>
// Constructor
AccountManager::AccountManager() : AccountManager(true){

}

AccountManager::AccountManager(bool autoSave){
    accountCount = 0;
    rosterAutoSave = autoSave;
}

// Add a new account
bool AccountManager::AddAccount(std::string& username) {

    /* Check if the username already exists in the map,
    iter is just a variable name i gave to the iterator*/
    auto iter = accounts.find(username);
    if (iter != accounts.end()) {
        return false; // Username taken
    }

    // Create a new account using the helper function
    BankAccount* accountPtr = AccountUtils::MakeAccount();

    if (accountPtr != nullptr) {
    accounts[username] = accountPtr;
    accountCount++;
    return true;
} else {
    return false; // account creation failed
}
}

// Delete an account
bool AccountManager::DeleteAccount(std::string& username) {

    // Find the account in the map
    auto iter = accounts.find(username);

    // If not found, return false
    if (iter == accounts.end()) {
        return false;
    }

    // Get the pointer to the BankAccount
    BankAccount* accountPtr = iter->second;

    // Delete the dynamically allocated account
    delete accountPtr;

    // Remove the entry from the map
    accounts.erase(iter);

    // Decrease account count
    accountCount--;
    return true;
}

// Display account info
void AccountManager::DisplayAccount(std::string& username) {

    // Find the account
    auto iter = accounts.find(username);

    if (iter == accounts.end()) {
        IOUtils::ErrorMessage("Account not found.");
        return;
    }

    // Get the BankAccount pointer
    BankAccount* accountPtr = iter->second;
    // Call Display on the account using * and .
    std::cout << accountPtr->ToString() << std::endl;
}
// Withdraw money
bool AccountManager::MakeWithdrawal(std::string& username, double amount) {

    // Find the account
    auto iter = accounts.find(username);

    if (iter == accounts.end()) {
        return false;
    }

    BankAccount* accountPtr = iter->second;

    // Withdraw returns true if enough balance, false if not
    return accountPtr->Withdrawal(amount);
}
// Deposit money
bool AccountManager::MakeDeposit(std::string& username, double amount) {

    // Find the account
    auto iter = accounts.find(username);

    if (iter == accounts.end()) {
        return false;
    }

    BankAccount* accountPtr = iter->second;

    // Deposit the money
    accountPtr->Deposit(amount);
    return true;
}
// Add interest to all accounts
void AccountManager::AddInterest() {

    // Loop through every account in the map
    for (auto iter = accounts.begin(); iter != accounts.end(); ++iter) {

        // Get the BankAccount pointer
        BankAccount* accountPtr = iter->second;

        if(SavingsAccount* savingsAccountPtr = dynamic_cast<SavingsAccount*>(accountPtr)){
            savingsAccountPtr->AccrueInterest();
        }
    }
}

// Write a check from one user to another
bool AccountManager::WriteCheck(std::string& checkWriter,
                                std::string& checkReceiver,
                                double amount) {

    // Find the writer
    auto writerIter = accounts.find(checkWriter);
    if (writerIter == accounts.end()) {
        return false;
    }

    // Find the receiver
    auto receiverIter = accounts.find(checkReceiver);
    if (receiverIter == accounts.end()) {
        return false;
    }

    // Get BankAccount pointers
    if(CheckingAccount* writerPtr = dynamic_cast<CheckingAccount*>(writerIter->second)){
        BankAccount* receiverPtr = receiverIter->second;

        // Attempt to withdraw money from writer
        if(writerPtr->WriteCheck(*receiverPtr, amount)){
            return true; // Transfer was successful
        }
    }
    return false;
}
// Get account count
int AccountManager::GetAccountCount() {
    return accountCount;
}

void AccountManager::Serialize(std::string filename){

    IOUtils::StatusMessage("Saving Account Roster...");

    std::ofstream savefile(filename);

    if(!savefile){

        IOUtils::ErrorMessage("Could not initialize " + filename + " for writing:" + " Attempting to write to TEMP_ROSTER_SAVE.csv");

        savefile.clear(); // Clear error state

        // Attempt to write to an alternative temporary file
        savefile.open("TEMP_ROSTER_SAVE.csv");

        if(!savefile){
            IOUtils::ErrorMessage("Attempt to write to fallback file TEMP_ROSTER_SAVE.csv failed. Any modifications since last save will not be written to disc."); 
            return;
        }
    }

    for (auto iter = accounts.begin(); iter != accounts.end(); ++iter) {

        std::string accountType;

        if(dynamic_cast<CheckingAccount*>(iter->second)){
            accountType = "Checking";
        }
        else if(dynamic_cast<SavingsAccount*>(iter->second)){
            accountType = "Savings";
        }
        else{
            accountType = "Unknown";
        }

        // Write account data to file
        savefile << iter->first << ',' << accountType << ',' << iter->second->Serialize();

        if((std::next(iter)) != accounts.end()){ // Print endl for all lines except the last line
            savefile << std::endl;
        }

    }

    savefile.close();

    IOUtils::StatusMessage("Saving Complete!");
}

void AccountManager::Deserialize(std::string filename) {

    IOUtils::StatusMessage("Loading Account Roster...");

    std::ifstream savefile(filename);

    std::string line;
    while(getline(savefile, line)){

        std::vector<std::string> parsedLine;

        boost::algorithm::split(parsedLine, line, boost::is_any_of(","));

        // Find the account
        auto iter = accounts.find(parsedLine.at(0));

        if (iter != accounts.end()) {
            throw std::runtime_error("File: \"" + filename + "\" corrupted or in invalid format: Duplicate accounts with matching usernames");
        }

        std::string accountTypeStr = parsedLine.at(1);

        try{
            if(accountTypeStr == "Savings"){
                accounts[parsedLine.at(0)] = new SavingsAccount(parsedLine.at(2), parsedLine.at(3), stod(parsedLine.at(4)), stod(parsedLine.at(5)));
                accountCount++;
            }
            else if (accountTypeStr == "Checking"){

                std::list<double> checkLog;

                for(size_t i = 5; i < parsedLine.size(); i++){
                    checkLog.push_back(stod(parsedLine.at(i)));
                }

                accounts[parsedLine.at(0)] = new CheckingAccount(parsedLine.at(2), parsedLine.at(3), stod(parsedLine.at(4)), checkLog);
                accountCount++;
            }
            else{
                throw std::runtime_error("File: \"" + filename + "\" corrupted or in invalid format: No account type \"" + accountTypeStr + "\" not found");
            }
        }
        catch (const std::exception& e) {
            throw std::runtime_error("File: \"" + filename + "\" corrupted or in invalid format: " + e.what());
        }
    }

    IOUtils::StatusMessage("Loading Complete!");

}

// Destructor
AccountManager::~AccountManager() {

    if(rosterAutoSave){
        // Save account data
        Serialize();
    }

    // Loop through every account
    for (auto iter = accounts.begin(); iter != accounts.end(); ++iter) {

        // Delete the dynamically allocated BankAccount
        delete iter->second;
    }

    // Clear the map
    accounts.clear();
}