#include "SavingsAccount.hpp"

SavingsAccount::SavingsAccount(std::string first, std::string last, double initBalance, double interest) : BankAccount(first, last, initBalance){
    m_InterestRate = interest;
}

SavingsAccount::SavingsAccount(std::string first, std::string last, double interest) : BankAccount(first, last){
    m_InterestRate = interest;
}

void SavingsAccount::AccrueInterest(){
    double interest = m_InterestRate * GetBalance();
    Deposit(interest);
}

std::string SavingsAccount::ToString(){
    return "Savings Account Balance: $" + std::to_string(GetBalance()) + ", Interest Rate: " + std::to_string(m_InterestRate);
}

std::string SavingsAccount::Serialize(){
    
    std::array<std::string, 4> data = {GetFirstName(), GetLastName(), std::to_string(GetBalance()), std::to_string(m_InterestRate)};

    return boost::algorithm::join(data, ",");
}

double SavingsAccount::GetInterestRate(){
    return m_InterestRate;
}

void SavingsAccount::SetInterestRate(double interest){
    m_InterestRate = interest;
}