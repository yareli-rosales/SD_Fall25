#include "CheckingAccount.hpp"

CheckingAccount::CheckingAccount(std::string first, std::string last, double initBalance, std::list<double> initCheckLog) : BankAccount(first, last, initBalance), m_CheckLog(initCheckLog) {

}

CheckingAccount::CheckingAccount(std::string first, std::string last, double initBalance) : BankAccount(first, last, initBalance) {

}

CheckingAccount::CheckingAccount(std::string first, std::string last) : BankAccount(first, last){

}

bool CheckingAccount::WriteCheck(BankAccount &a, double amount){
    bool success = Withdrawal(amount);

    if(success){
        a.Deposit(amount);
        m_CheckLog.push_back(amount);
    }

    return success;
}

std::string CheckingAccount::ToString(){
    return "Checking Account Balance: $" + std::to_string(GetBalance());
}

std::string CheckingAccount::Serialize(){
    std::vector<std::string> data = {GetFirstName(), GetLastName(), std::to_string(GetBalance())};

    for(auto& item : m_CheckLog){
        data.push_back(std::to_string(item));
    }

    return boost::algorithm::join(data, ",");
}



std::list<double> CheckingAccount::GetCheckLog(){
    return m_CheckLog;
}