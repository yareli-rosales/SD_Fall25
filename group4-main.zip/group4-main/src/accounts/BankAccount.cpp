#include "BankAccount.hpp"
#include "Utils.hpp"
#include <iostream>

BankAccount::BankAccount(std::string first, std::string last, double initBalance){
    m_FirstName = first;
    m_LastName = last;
    m_Balance = initBalance;
}

BankAccount::BankAccount(std::string first, std::string last) : BankAccount(first, last, 0){

}

double BankAccount::GetBalance(){
    return m_Balance;
}

std::string BankAccount::GetFirstName(){
    return m_FirstName;
}

std::string BankAccount::GetLastName(){
    return m_LastName;
}

void BankAccount::SetFirstName(std::string name){
    m_FirstName = name;
}

void BankAccount::SetLastName(std::string name){
    m_LastName = name;
}

bool BankAccount::Withdrawal(double amount){
    if(amount > 0){
        if(amount <= m_Balance){
            m_Balance = m_Balance - amount;
            return true;
        }
        else {
            IOUtils::ErrorMessage("Withdrawal amount greater than balance.");
            return false;
        }
    }
    else {
        IOUtils::ErrorMessage("Invalid amount to withdrawal. Must be positive.");
        return false;
    }
}

bool BankAccount::Deposit(double amount){
    if(amount > 0){
        m_Balance = m_Balance + amount;
        return true;
    }
    else {
        IOUtils::ErrorMessage("Invalid amount to deposit. Must be positive.");
        return false;
    }
}