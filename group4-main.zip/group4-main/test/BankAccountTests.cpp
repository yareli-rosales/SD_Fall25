#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MAIN
#include "CheckingAccount.hpp"
#include "SavingsAccount.hpp"
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_SUITE(bank_account_suite, * boost::unit_test::timeout(10))
// Test both constructors
BOOST_AUTO_TEST_CASE(test_checking_account_base_methods) {

    CheckingAccount acc("First", "Last", 100.0);

    BOOST_CHECK_EQUAL(acc.GetFirstName(), "First");
    BOOST_CHECK_EQUAL(acc.GetLastName(), "Last");

    BOOST_CHECK(acc.Deposit(50.0));
    BOOST_CHECK_EQUAL(acc.GetBalance(), 150.0);

    BOOST_CHECK(acc.Withdrawal(70.0));
    BOOST_CHECK_EQUAL(acc.GetBalance(), 80.0);

    BOOST_CHECK(!acc.Withdrawal(200.0));
    BOOST_CHECK_EQUAL(acc.GetBalance(), 80.0);

}

// Test getters
BOOST_AUTO_TEST_CASE(test_write_check) {
    CheckingAccount writer("Writer", "Person", 300.0);
    CheckingAccount receiver("Receiver", "Person", 50.0);

    bool success = writer.WriteCheck(receiver, 100.0);
    BOOST_CHECK(success);
    BOOST_CHECK_EQUAL(writer.GetBalance(), 200.0);
    BOOST_CHECK_EQUAL(receiver.GetBalance(), 150.0);

    // Test insufficient funds
    BOOST_CHECK(!writer.WriteCheck(receiver, 500.0));
    BOOST_CHECK_EQUAL(writer.GetBalance(), 200.0);

    // Test negative check amount
    BOOST_CHECK(!writer.WriteCheck(receiver, -50.0));

}

// Test setters
BOOST_AUTO_TEST_CASE(test_savings_account_base_methods) {
    SavingsAccount acc("Saver", "Person", 100.0, 0.05); // 5% interest

    BOOST_CHECK(acc.Deposit(50.0));
    BOOST_CHECK_EQUAL(acc.GetBalance(), 150.0);

    BOOST_CHECK(acc.Withdrawal(20.0));
    BOOST_CHECK_EQUAL(acc.GetBalance(), 130.0);

    // Withdrawal exceeding balance
    BOOST_CHECK(!acc.Withdrawal(500.0));

}

// Test deposit
BOOST_AUTO_TEST_CASE(test_savings_account_interest) {
    SavingsAccount acc("Saver", "Person", 100.0, 0.10); // 10% interest

    // Accrue interest
    acc.AccrueInterest();
    BOOST_CHECK_CLOSE(acc.GetBalance(), 110.0, 1e-6);

    // Change interest rate
    acc.SetInterestRate(0.05);
    BOOST_CHECK_EQUAL(acc.GetInterestRate(), 0.05);

}


BOOST_AUTO_TEST_SUITE_END()