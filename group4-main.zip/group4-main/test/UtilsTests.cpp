#define BOOST_TEST_DYN_LINK

#include "StreamRedirect.hpp"
#include "Utils.hpp"
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_SUITE(utils_suite, * boost::unit_test::timeout(10))

    BOOST_AUTO_TEST_SUITE(io_suite, * boost::unit_test::timeout(10))

        BOOST_AUTO_TEST_CASE(status_message_test){
            std::string prompt = "This is a test";
            std::string expectedString = "[STATUS]: " + prompt + "\n";
            std::streambuf* oldCoutBuffer = std::cout.rdbuf();
            std::ostringstream capturedOutput;
            std::cout.rdbuf(capturedOutput.rdbuf());
            IOUtils::StatusMessage(prompt);
            std::cout.rdbuf(oldCoutBuffer);
            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedString);
        }

        BOOST_AUTO_TEST_CASE(error_message_test){
            std::string prompt = "This is an error test";
            std::string expectedString = "[ERROR]: " + prompt + "\n";
            std::streambuf* oldCoutBuffer = std::cout.rdbuf();
            std::ostringstream capturedOutput;
            std::cout.rdbuf(capturedOutput.rdbuf());
            IOUtils::ErrorMessage(prompt);
            std::cout.rdbuf(oldCoutBuffer);
            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedString);
        }
        
        BOOST_AUTO_TEST_CASE(clear_screen_test){
            std::string expectedString = "\033[2J\033[1;1H";
            std::streambuf* oldCoutBuffer = std::cout.rdbuf();
            std::ostringstream capturedOutput;
            std::cout.rdbuf(capturedOutput.rdbuf());
            IOUtils::ClearScreen();
            std::cout.rdbuf(oldCoutBuffer);
            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedString);
        }

        BOOST_AUTO_TEST_CASE(get_string_test){
            std::string prompt = "getString test";
            std::string expectedString = prompt + "\n";
            std::string userInput = "2";
            std::string expectedReturn = userInput;

            std::istringstream inputStream(userInput);
            std::streambuf* oldCinBuffer = std::cin.rdbuf(inputStream.rdbuf());

            std::ostringstream capturedOutput;
            std::streambuf* oldCoutBuffer = std::cout.rdbuf(capturedOutput.rdbuf());

            std::string realReturn = IOUtils::GetString(prompt);
            std::cout.rdbuf(oldCoutBuffer);
            std::cin.rdbuf(oldCinBuffer);

            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedString);
            BOOST_CHECK_EQUAL(realReturn, expectedReturn);
        }
        
        BOOST_AUTO_TEST_CASE(get_double_success_test){
            std::string prompt = "getDouble test";
            std::string userInput = "123.123";
            double expectedReturn = 123.123;
            std::string expectedOutput = prompt + "\n";

            std::istringstream inputStream(userInput);
            std::streambuf* oldCinBuffer = std::cin.rdbuf(inputStream.rdbuf());

            std::ostringstream capturedOutput;
            std::streambuf* oldCoutBuffer = std::cout.rdbuf(capturedOutput.rdbuf());

            double realReturn = IOUtils::GetDouble(prompt);
            std::cout.rdbuf(oldCoutBuffer);
            std::cin.rdbuf(oldCinBuffer);

            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedOutput);
            BOOST_CHECK_CLOSE(realReturn, expectedReturn, 0.00001);
        }

        BOOST_AUTO_TEST_CASE(get_double_fail_test){
            std::string prompt = "getDouble test";
            std::string userInput = "not a double";

            std::istringstream inputStream(userInput);
            std::streambuf* oldCinBuffer = std::cin.rdbuf(inputStream.rdbuf());

            std::ostringstream capturedOutput;
            std::streambuf* oldCoutBuffer = std::cout.rdbuf(capturedOutput.rdbuf());

            BOOST_CHECK_THROW(IOUtils::GetDouble(prompt), std::invalid_argument);

            std::cin.clear();
            std::cin.rdbuf(oldCinBuffer);
            std::cout.rdbuf(oldCoutBuffer);
        }

        BOOST_AUTO_TEST_CASE(get_option_fail_to_success_test){

            std::string mockClearScreen = "\033[2J\033[1;1H";
            std::string errorMsg = "Error: Invalid Choice. Input couldnt be cast to size_t.\n";

            std::string menuPrompt = 
                "Options\n"
                "0) Exit\n"
                "1) Make account\n"
                "2) Deposit to existing account\n"
                "3) Withdraw from existing account\n"
                "4) Display existing account\n"
                "5) Accrue Interest\n"
                "6) Write a check\n"
                "What would you like to do (Input single number):\n";

            std::string mockInput = "invalid\n\n5\n"; 
            size_t expectedReturn = 5;

            std::string expectedOut = 
                menuPrompt + 
                errorMsg + 
                mockClearScreen +
                menuPrompt;
            
            std::istringstream inputStream(mockInput);
            std::streambuf* oldCin = std::cin.rdbuf(inputStream.rdbuf());
        
            std::ostringstream capturedOutput;
            std::streambuf* oldCout = std::cout.rdbuf(capturedOutput.rdbuf());

            size_t realReturn = IOUtils::MainMenu::GetOption();

            std::cin.clear(); 
            std::cin.rdbuf(oldCin);
            std::cout.rdbuf(oldCout);

            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedOut);
            BOOST_CHECK_EQUAL(realReturn, expectedReturn);
        }

        BOOST_AUTO_TEST_CASE(get_option_success_test){

            std::string menuPrompt = 
                "Options\n"
                "0) Exit\n"
                "1) Make account\n"
                "2) Deposit to existing account\n"
                "3) Withdraw from existing account\n"
                "4) Display existing account\n"
                "5) Accrue Interest\n"
                "6) Write a check\n"
                "What would you like to do (Input single number):\n";

            std::string mockInput = "5\n\n"; 
            size_t expectedReturn = 5;

            std::string expectedOut = menuPrompt;
            
            std::istringstream inputStream(mockInput);
            std::streambuf* oldCin = std::cin.rdbuf(inputStream.rdbuf());
        
            std::ostringstream capturedOutput;
            std::streambuf* oldCout = std::cout.rdbuf(capturedOutput.rdbuf());

            size_t realReturn = IOUtils::MainMenu::GetOption();

            std::cin.rdbuf(oldCin);
            std::cout.rdbuf(oldCout);

            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedOut);
            BOOST_CHECK_EQUAL(realReturn, expectedReturn);
        }

        BOOST_AUTO_TEST_CASE(get_option_out_of_range_fail_to_success_test){

            std::string menuPrompt = 
                "Options\n"
                "0) Exit\n"
                "1) Make account\n"
                "2) Deposit to existing account\n"
                "3) Withdraw from existing account\n"
                "4) Display existing account\n"
                "5) Accrue Interest\n"
                "6) Write a check\n"
                "What would you like to do (Input single number):\n";

            std::string mockInput = "123\n\n5\n"; 
            size_t expectedReturn = 5;
            std::string errorMsg = "Error: Option Not Found\n";
            std::string mockClearScreen = "\033[2J\033[1;1H";

            std::string expectedOut = menuPrompt + errorMsg + mockClearScreen + menuPrompt;
            
            std::istringstream inputStream(mockInput);
            std::streambuf* oldCin = std::cin.rdbuf(inputStream.rdbuf());
        
            std::ostringstream capturedOutput;
            std::streambuf* oldCout = std::cout.rdbuf(capturedOutput.rdbuf());

            size_t realReturn = IOUtils::MainMenu::GetOption();

            std::cin.clear(); 
            std::cin.rdbuf(oldCin);
            std::cout.rdbuf(oldCout);

            BOOST_CHECK_EQUAL(capturedOutput.str(), expectedOut);
            BOOST_CHECK_EQUAL(realReturn, expectedReturn);
        }

    BOOST_AUTO_TEST_SUITE_END()

BOOST_AUTO_TEST_SUITE_END()