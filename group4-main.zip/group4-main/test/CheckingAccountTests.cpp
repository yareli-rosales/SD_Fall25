#define BOOST_TEST_DYN_LINK

#include <boost/test/unit_test.hpp>

#include "CheckingAccount.hpp"
#include "BankAccount.hpp"

BOOST_AUTO_TEST_SUITE(checking_account_suite, * boost::unit_test::timeout(10))

BOOST_AUTO_TEST_CASE(test_constructor_with_balance_and_initial_check_log) {

    CheckingAccount acc("Jane", "Adams", 200, {50, 100, 200});

    BOOST_CHECK_EQUAL(acc.GetFirstName(), "Jane");
    BOOST_CHECK_EQUAL(acc.GetLastName(), "Adams");
    BOOST_CHECK_EQUAL(acc.GetBalance(), 200);

    
    auto log = acc.GetCheckLog();

    //check log should contain three entries
    BOOST_REQUIRE_EQUAL(log.size(), 3);

    //check log should be {50, 100, 200}
    auto it = log.begin();
    BOOST_CHECK_EQUAL(*it, 50); ++it;
    BOOST_CHECK_EQUAL(*it, 100); ++it;
    BOOST_CHECK_EQUAL(*it, 200);

}

BOOST_AUTO_TEST_CASE(test_constructor_with_balance) {

    CheckingAccount acc("John", "Doe", 200.00);

    BOOST_CHECK_EQUAL(acc.GetFirstName(), "John");
    BOOST_CHECK_EQUAL(acc.GetLastName(), "Doe");
    BOOST_CHECK_EQUAL(acc.GetBalance(), 200.00);
}

BOOST_AUTO_TEST_CASE(test_constructor_without_balance) {

    CheckingAccount acc("Jane", "Adams");

    BOOST_CHECK_EQUAL(acc.GetFirstName(), "Jane");
    BOOST_CHECK_EQUAL(acc.GetLastName(), "Adams");
    BOOST_CHECK_EQUAL(acc.GetBalance(), 0.00);
}

BOOST_AUTO_TEST_CASE(test_write_check_sucess) {
    
    CheckingAccount writer("Writer", "Person", 300.00);
    CheckingAccount receiver("Receiver", "Person", 50.00);

    bool result = writer.WriteCheck(receiver, 100.00);

    BOOST_CHECK(result == true);
    BOOST_CHECK_EQUAL(writer.GetBalance(), 200.00);
    BOOST_CHECK_EQUAL(receiver.GetBalance(), 150.00);

    //check log should contain exactly one entry
    auto log = writer.GetCheckLog();
    BOOST_REQUIRE_EQUAL(log.size(), 1);
    BOOST_CHECK_EQUAL(log.front(), 100.00);

}

BOOST_AUTO_TEST_CASE(test_write_check_failure_low_funds) {
    CheckingAccount writer("Writer", "Person", 50.00);
    CheckingAccount receiver("Receiver", "Person", 0.00);

    bool result = writer.WriteCheck(receiver, 200.00);

    BOOST_CHECK(result == false);
    BOOST_CHECK_EQUAL(writer.GetBalance(), 50.00);
    BOOST_CHECK_EQUAL(receiver.GetBalance(), 0.00);

    auto log = writer.GetCheckLog();
    BOOST_CHECK_EQUAL(log.size(), 0);

}

BOOST_AUTO_TEST_CASE(test_write_check_invalid_amount) {
    CheckingAccount writer("Writer", "Person", 200.00);
    CheckingAccount receiver("Receiver", "Person", 0.00);

    bool result = writer.WriteCheck(receiver, -10.00);

    BOOST_CHECK(result == false);
    BOOST_CHECK_EQUAL(writer.GetBalance(), 200.00);
    BOOST_CHECK_EQUAL(receiver.GetBalance(), 0.00);

    auto log = writer.GetCheckLog();
    BOOST_CHECK_EQUAL(log.size(), 0);
}

BOOST_AUTO_TEST_CASE(test_multiple_checks_logged) {
    CheckingAccount writer("Writer", "Person", 1000.00);
    CheckingAccount receiver("Receiver", "Person", 0.00);

    writer.WriteCheck(receiver, 100.00);
    writer.WriteCheck(receiver, 200.00);
    writer.WriteCheck(receiver, 50.00);

    auto log = writer.GetCheckLog();

    BOOST_REQUIRE_EQUAL(log.size(), 3);

    auto it = log.begin();
    BOOST_CHECK_EQUAL(*it, 100.00); ++it;
    BOOST_CHECK_EQUAL(*it, 200.00); ++it;
    BOOST_CHECK_EQUAL(*it, 50.00);
}


BOOST_AUTO_TEST_CASE(test_serialization) {
    CheckingAccount acc("Jane", "Adams", 200, {50, 100, 200});
    std::string expectedStr = "Jane,Adams,200.000000,50.000000,100.000000,200.000000";

    BOOST_CHECK_EQUAL(acc.Serialize(), expectedStr);
    
}

BOOST_AUTO_TEST_SUITE_END()