#define BOOST_TEST_DYN_LINK
#include "AccountManager.hpp"
#include "BankAccount.hpp"
#include "StreamRedirect.hpp"
#include <string>
#include <fstream>

#include <boost/test/unit_test.hpp>

// Test suite for AccountManager
BOOST_AUTO_TEST_SUITE(account_manager_suite, *boost::unit_test::timeout(10))

    // Test the constructor
    BOOST_AUTO_TEST_CASE(test_constructor) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 0);
    }

    // Test adding an account
    BOOST_AUTO_TEST_CASE(test_add_account) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled

        IOUtils::StreamRedirect redirectIn(std::cin);

        std::string username = "user1";

        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl; 
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        bool added = manager.AddAccount(username);
        
        redirectIn.Revert();
        
        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();
        

        BOOST_CHECK(added);
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 1);

        // Try adding the same username again
        added = manager.AddAccount(username);
        BOOST_CHECK(!added);
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 1);
    }
    
    // Test deleting an account
    BOOST_AUTO_TEST_CASE(test_delete_account) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled

        IOUtils::StreamRedirect redirectIn(std::cin);

        std::string username = "user1";

        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        bool added = manager.AddAccount(username);
        
        redirectIn.Revert();

        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        BOOST_CHECK(added);
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 1);

        // Delete existing account
        bool deleted = manager.DeleteAccount(username);
        BOOST_CHECK(deleted);
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 0);

        // Delete non-existent account
        deleted = manager.DeleteAccount(username);
        BOOST_CHECK(!deleted);
    }

    // Test displaying an account
    BOOST_AUTO_TEST_CASE(test_display_account) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled

        IOUtils::StreamRedirect redirectIn(std::cin);
        IOUtils::StreamRedirect redirectOut(std::cout);

        std::string user1 = "user1";

        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        bool added = manager.AddAccount(user1);
        
        redirectIn.Revert();

        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        BOOST_CHECK(added);
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 1);

        BOOST_REQUIRE(redirectOut.Divert());

        manager.DisplayAccount(user1);

        redirectOut.Revert(); // Revert the stream 
        BOOST_TEST_MESSAGE("\nDiverted Stream Buffer:\n" + redirectOut.str()); // Print the diverted stream buffer for clearer program flow

        std::string displayStr = redirectOut.str(); // Store the captured output in a string

        // Empty the buffer and clear error flags.
        redirectOut.str("");
        redirectOut.clear();

        BOOST_CHECK_EQUAL(displayStr, "Savings Account Balance: $0.000000, Interest Rate: 0.100000\n");

        // Display a non-existent account
        std::string user2 = "nonexistent";

        BOOST_REQUIRE(redirectOut.Divert());

        manager.DisplayAccount(user2);

        redirectOut.Revert(); // Revert the stream 
        BOOST_TEST_MESSAGE("\nDiverted Stream Buffer:\n" + redirectOut.str()); // Print the diverted stream buffer for clearer program flow

        displayStr = redirectOut.str(); // Store the captured output in a string

        // Empty the buffer and clear error flags.
        redirectOut.str("");
        redirectOut.clear();

        BOOST_CHECK_EQUAL(displayStr, "[ERROR]: Account not found.\n");

    }
    
    BOOST_AUTO_TEST_CASE(test_make_withdrawal) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled
        
        IOUtils::StreamRedirect redirectIn(std::cin);

        std::string user1 = "user1";

        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        bool added = manager.AddAccount(user1);
        
        redirectIn.Revert();
        
        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        // Deposit money so we CAN withdraw
        BOOST_CHECK(manager.MakeDeposit(user1, 100.0));

        // Withdraw a valid amount
        BOOST_CHECK(manager.MakeWithdrawal(user1, 50.0));

        // Try withdrawing more than the balance
        BOOST_CHECK(!manager.MakeWithdrawal(user1, 100.0)); // should fail

        // Try withdrawing from an account that does not exist
        std::string user2 = "ghost";
        BOOST_CHECK(!manager.MakeWithdrawal(user2, 10.0));
    }

    // Test MakeDeposit
    BOOST_AUTO_TEST_CASE(test_make_deposit) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled
        
        IOUtils::StreamRedirect redirectIn(std::cin);
        IOUtils::StreamRedirect redirectOut(std::cout);

        std::string user1 = "user1";

        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        bool added = manager.AddAccount(user1);
        
        redirectIn.Revert();

        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        // Make a valid deposit
        BOOST_CHECK(manager.MakeDeposit(user1, 100.0));

        // Try depositing from an account that does not exist
        std::string user2 = "ghost";
        BOOST_CHECK(!manager.MakeDeposit(user2, 100.0));
    }
    
    // Test AddInterest
    BOOST_AUTO_TEST_CASE(test_add_interest) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled
        
        IOUtils::StreamRedirect redirectIn(std::cin);
        IOUtils::StreamRedirect redirectOut(std::cout);

        std::string user1 = "BIG-JT";
        
        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        BOOST_CHECK(manager.AddAccount(user1));
        
        redirectIn.Revert();

        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();


        std::string user2 = "Veriphi";

        BOOST_REQUIRE(redirectIn.Divert());
        
        redirectIn << "Fred" << std::endl; // Queue up sudo user input
        redirectIn << "Verify" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        BOOST_CHECK(manager.AddAccount(user2));

        redirectIn.Revert();
        
        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        // Deposit initial amounts
        manager.MakeDeposit(user1, 100.0);
        manager.MakeDeposit(user2, 200.0);

        // Apply interest to all accounts
        manager.AddInterest();

        BOOST_REQUIRE(redirectOut.Divert());

        manager.DisplayAccount(user1);

        redirectOut.Revert(); // Revert the stream 
        BOOST_TEST_MESSAGE("\nDiverted Stream Buffer:\n" + redirectOut.str()); // Print the diverted stream buffer for clearer program flow

        std::string displayStr = redirectOut.str(); // Store the captured output in a string

        // Empty the buffer and clear error flags.
        redirectOut.str("");
        redirectOut.clear();

        BOOST_CHECK_EQUAL(displayStr, "Savings Account Balance: $110.000000, Interest Rate: 0.100000\n");

        BOOST_REQUIRE(redirectOut.Divert());

        manager.DisplayAccount(user2);

        redirectOut.Revert(); // Revert the stream 
        BOOST_TEST_MESSAGE("\nDiverted Stream Buffer:\n" + redirectOut.str()); // Print the diverted stream buffer for clearer program flow

        displayStr = redirectOut.str(); // Store the captured output in a string

        // Empty the buffer and clear error flags.
        redirectOut.str("");
        redirectOut.clear();

        BOOST_CHECK_EQUAL(displayStr, "Savings Account Balance: $220.000000, Interest Rate: 0.100000\n");
    }

   
    // Test WriteCheck
    BOOST_AUTO_TEST_CASE(test_write_check) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled
        
        IOUtils::StreamRedirect redirectIn(std::cin);
        IOUtils::StreamRedirect redirectOut(std::cout);

        std::string writer = "BIG-JT";
        
        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl;
        redirectIn << "2" << std::endl;

        BOOST_CHECK(manager.AddAccount(writer));
        
        redirectIn.Revert();

        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        std::string receiver = "Veriphi";

        BOOST_REQUIRE(redirectIn.Divert());
        
        redirectIn << "Fred" << std::endl; // Queue up sudo user input
        redirectIn << "Verify" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        BOOST_CHECK(manager.AddAccount(receiver));

        redirectIn.Revert();
        
        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        // Deposit money into the check writer
        BOOST_CHECK(manager.MakeDeposit(writer, 100.0));

        // Write a check for 50.00
        BOOST_CHECK(manager.WriteCheck(writer, receiver, 50.0));

        // Writer does not exist
        std::string ghost = "nonexistent";
        BOOST_CHECK(!manager.WriteCheck(ghost, receiver, 50.0));

        // Receiver does not exist
        std::string ghost2 = "nobody";
        BOOST_CHECK(!manager.WriteCheck(writer, ghost2, 50.0));

        // Insufficient funds
        BOOST_CHECK(!manager.WriteCheck(writer, receiver, 500.0));
    }

    // Test GetAccountCount
    BOOST_AUTO_TEST_CASE(test_get_account_count) {
        AccountManager manager(0); // Explicity construct with automatic roster saving disabled
        
        IOUtils::StreamRedirect redirectIn(std::cin);
        IOUtils::StreamRedirect redirectOut(std::cout);

        // Initially empty
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 0);

        std::string user1 = "BIG-JT";
        
        BOOST_REQUIRE(redirectIn.Divert());

        redirectIn << "John" << std::endl; // Queue up sudo user input
        redirectIn << "Test" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        BOOST_CHECK(manager.AddAccount(user1));
        
        redirectIn.Revert();

        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        // Check that the counter is 1 after adding the first account
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 1);

        std::string user2 = "Veriphi";

        BOOST_REQUIRE(redirectIn.Divert());
        
        redirectIn << "Fred" << std::endl; // Queue up sudo user input
        redirectIn << "Verify" << std::endl;
        redirectIn << "1" << std::endl;
        redirectIn << .10 << std::endl;

        BOOST_CHECK(manager.AddAccount(user2));

        redirectIn.Revert();
        
        // Empty the buffer and clear error flags.
        redirectIn.str("");
        redirectIn.clear();

        // Check that the counter increased to 2 after adding another account
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 2);

        // Delete the first account
        manager.DeleteAccount(user1);
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 1);

        // Delete the second account
        manager.DeleteAccount(user2);
        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 0);
    }

    // Test to validate automatic (on destructor) auto saving (serialization) and roster reading from file (deserialization) at start up 
    BOOST_AUTO_TEST_CASE(test_serialization_auto_save){
        
        // Attempt to open the default savefile "Bank_Account_Roster.csv"
        std::fstream savefile("Bank_Account_Roster.csv");

        // 1. Savings Account String
        std::string line1 = "alpha,Savings,Alice,Smith,15000.750000,0.045000";
        
        // 2. Checking Account String
        std::string line2 = "beta,Checking,Bob,Jones,22345.000000,500.000000,12.500000";
        
        // 3. Savings Account String
        std::string line3 = "gamma,Savings,Gary,Dean,879.440000,0.038000";

        // Write the string variables to the file stream
        savefile << line1 << std::endl;
        savefile << line2 << std::endl;
        savefile << line3;

        savefile.close();

        AccountManager manager; // Create manager via default constructor (auto saving on destruction is enabled)
        std::string tempRead;

        manager.Deserialize(); // Construct account roster from the default savefile "Bank_Account_Roster.csv"

        BOOST_CHECK_EQUAL(manager.GetAccountCount(), 3); // 3 accounts should have been read into memory from the savefile

        std::string username = "alpha";
        manager.DeleteAccount(username); // Delete the first of the 3 accounts

        manager.~AccountManager(); // Call destructor which should serialize to default savefile

        savefile.open("Bank_Account_Roster.csv");

        // The save file should now only contain the second and third accounts from the original input 
        getline(savefile, tempRead);
        BOOST_CHECK_EQUAL(tempRead, line2); // Check line2
        
        getline(savefile, tempRead);
        BOOST_CHECK_EQUAL(tempRead, line3); // Check line3

        savefile.close();

    }

    // Test to validate manual serialization management. (Essentially when the destructor should not auto save the roster to a file)
    BOOST_AUTO_TEST_CASE(test_serialization_manual_save){
        
        // Attempt to open the default savefile "Bank_Account_Roster.csv"
        std::fstream savefile("Bank_Account_Roster.csv");

        // 1. Savings Account String
        std::string line1 = "alpha,Savings,Alice,Smith,15000.750000,0.045000";
        
        // 2. Checking Account String
        std::string line2 = "beta,Checking,Bob,Jones,22345.000000,500.000000,12.500000";
        
        // 3. Savings Account String
        std::string line3 = "gamma,Savings,Gary,Dean,879.440000,0.038000";

        // Write the string variables to the file stream
        savefile << line1 << std::endl;
        savefile << line2 << std::endl;
        savefile << line3;

        savefile.close();

        AccountManager manager(0); // Explicity construct with automatic roster saving disabled
        std::string username = "alpha";
        std::string tempRead;

        manager.Deserialize(); // Construct account roster from the default savefile "Bank_Account_Roster.csv"

        manager.DeleteAccount(username); // Delete the first of the 3 accounts

        manager.Serialize("TEST_ALTERNATIVE_SAVE.csv"); // Try saving the data to an alternative save file

        manager.~AccountManager(); // Call destructor. In this case it should try to save and therefore the default file will not have the new changes

        savefile.open("Bank_Account_Roster.csv");

        // The default savefile should have all of the original input
        getline(savefile, tempRead);
        BOOST_CHECK_EQUAL(tempRead, line1); // Check line1
        
        getline(savefile, tempRead);
        BOOST_CHECK_EQUAL(tempRead, line2); // Check line2
        
        getline(savefile, tempRead);
        BOOST_CHECK_EQUAL(tempRead, line3); // Check line3

        savefile.close();

        savefile.open("TEST_ALTERNATIVE_SAVE.csv");

        // The alternative savefile should contained the modified roster (only the accounts for beta and gamma)
        getline(savefile, tempRead);
        BOOST_CHECK_EQUAL(tempRead, line2); // Check line2
        
        getline(savefile, tempRead);
        BOOST_CHECK_EQUAL(tempRead, line3); // Check line3

        savefile.close();
    }

    BOOST_AUTO_TEST_SUITE_END()