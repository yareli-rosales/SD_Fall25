#define BOOST_TEST_DYN_LINK

#include <boost/test/unit_test.hpp>

#include "BankAccount.hpp"
#include "SavingsAccount.hpp"

BOOST_AUTO_TEST_SUITE(savings_account_suite, * boost::unit_test::timeout(10))


BOOST_AUTO_TEST_CASE(test_constructors) {

    // Constructor WITH initial balance
    SavingsAccount acc1("Jane", "Vogel", 100.0, 0.05);
    BOOST_CHECK_EQUAL(acc1.GetFirstName(), "Jane");
    BOOST_CHECK_EQUAL(acc1.GetLastName(), "Vogel");
    BOOST_CHECK_EQUAL(acc1.GetBalance(), 100.0);
    BOOST_CHECK_EQUAL(acc1.GetInterestRate(), 0.05);

    // Constructor WITHOUT initial balance (defaults to 0.0)
    SavingsAccount acc2("John", "Doe", 0.10);
    BOOST_CHECK_EQUAL(acc2.GetFirstName(), "John");
    BOOST_CHECK_EQUAL(acc2.GetLastName(), "Doe");
    BOOST_CHECK_EQUAL(acc2.GetBalance(), 0.0);   // default balance
    BOOST_CHECK_EQUAL(acc2.GetInterestRate(), 0.10);
} 


BOOST_AUTO_TEST_CASE(test_interest_rate_setter_getter) {
    SavingsAccount acc("Hana", "Brown", 50.0, 0.03);

    acc.SetInterestRate(0.08);
    BOOST_CHECK_EQUAL(acc.GetInterestRate(), 0.08);
}

BOOST_AUTO_TEST_CASE(test_acrrue_interest) {
    SavingsAccount acc("Phoebe", "Bridges", 200.0, 0.10);

    acc.AccrueInterest(); // 10% of 200 = 20 which is added
    BOOST_CHECK_EQUAL(acc.GetBalance(), 220.0);

    acc.AccrueInterest(); // 10% of 220 = 22 which is added
    BOOST_CHECK_EQUAL(acc.GetBalance(), 242.0);
}

BOOST_AUTO_TEST_CASE(test_serialization) {
    SavingsAccount acc("Phoebe", "Bridges", 200.0, 0.10);
    std::string expectedStr = "Phoebe,Bridges,200.000000,0.100000";

    BOOST_CHECK_EQUAL(acc.Serialize(), expectedStr);
}


BOOST_AUTO_TEST_SUITE_END()